
import numpy as np
from src.affective_agent import AffectiveAgent, AgentConfig

def test_recovery_trend():
    agent = AffectiveAgent(AgentConfig(), seed=0)
    out = agent.run_sequence(T=120, threat_time=60, novelty=0.9, control=0.5)
    # after peak, arousal should trend back down by the end
    ar = out["arousal"]
    assert ar[119] < ar[70], "Arousal should recover after the threat window"

def test_workspace_salience():
    agent = AffectiveAgent(AgentConfig(), seed=0)
    out = agent.run_sequence(T=120, threat_time=30, novelty=0.9, control=0.2)
    # around the threat, workspace should have some active channels
    ws_sum = out["workspace"][35:50].sum()
    assert ws_sum > 0, "Workspace should broadcast salient channels near the event"
