
"""
A minimal affective agent that integrates:
- Interoception: synthetic body signals (HR, HRV, EDA, Respiration, Pupil)
- Prediction error: mismatch between predicted and sensed intero states
- Global workspace: selects salient signal(s) based on surprise (error) and broadcasts
- Report: produces valence/arousal + short textual summary

The design is simple, transparent, and deterministic for reproducibility.
"""

from dataclasses import dataclass
import numpy as np

@dataclass
class AgentConfig:
    dt: float = 1.0
    baseline_hr: float = 70.0
    baseline_hrv: float = 40.0
    baseline_eda: float = 1.0
    baseline_resp: float = 12.0
    baseline_pupil: float = 3.4
    # sensitivity weights
    w_hr: float = 0.25
    w_hrv: float = 0.2
    w_eda: float = 0.25
    w_resp: float = 0.15
    w_pupil: float = 0.15
    # prediction update (simple exponential smoothing)
    alpha: float = 0.15
    # global workspace threshold (salience)
    salience_tau: float = 0.6

class AffectiveAgent:
    def __init__(self, cfg: AgentConfig = AgentConfig(), seed: int = 0):
        self.cfg = cfg
        self.rng = np.random.default_rng(seed)
        # internal predictions start at baselines
        self.pred = np.array([cfg.baseline_hr, cfg.baseline_hrv, cfg.baseline_eda,
                              cfg.baseline_resp, cfg.baseline_pupil], dtype=float)

    def step(self, intero: np.ndarray) -> dict:
        """
        One step update.
        intero: array([HR, HRV, EDA, Resp, Pupil])
        Returns dict with prediction error, workspace mask, valence, arousal, and report string.
        """
        cfg = self.cfg
        assert intero.shape == (5,), "intero must be 5-dim"
        # prediction error
        pe = intero - self.pred
        # update predictions (simple learner)
        self.pred = (1.0 - cfg.alpha) * self.pred + cfg.alpha * intero

        # salience: magnitude of standardized error
        scales = np.array([10.0, 8.0, 0.5, 2.0, 0.3])  # rough units to z-score-ish
        sal = np.abs(pe / scales)
        workspace = (sal >= cfg.salience_tau).astype(float)

        # aggregate to arousal/valence
        w = np.array([cfg.w_hr, cfg.w_hrv, cfg.w_eda, cfg.w_resp, cfg.w_pupil])
        arousal = float(np.clip((np.maximum(0, pe) * w).sum() / (w.sum()+1e-6), 0.0, 1.0))
        # valence: goal congruence proxy -> HRV up & EDA down are positive; HR up & Resp up negative
        valence = float(np.clip(((-pe[0]) + (pe[1]) + (-pe[2]) + (-pe[3]) + (0.2*pe[4])) / 50.0, -1.0, 1.0))

        # simple textual report
        channels = ["HR","HRV","EDA","Resp","Pupil"]
        salient = [ch for ch, m in zip(channels, workspace) if m > 0.5]
        if len(salient)==0:
            summary = "All clear; no salient body changes."
        else:
            summary = f"Broadcast: salient channels={salient}; arousal={arousal:.2f}, valence={valence:.2f}."

        return {
            "prediction_error": pe,
            "salience": sal,
            "workspace": workspace,
            "valence": valence,
            "arousal": arousal,
            "report": summary
        }

    def run_sequence(self, T=120, threat_time=60, novelty=0.9, control=0.3) -> dict:
        """
        Generate a synthetic scenario with a 'threat' at threat_time that raises HR, EDA, Resp
        and lowers HRV (less control => stronger response). Then recover.
        """
        cfg = self.cfg
        data = {
            "intero": np.zeros((T,5)),
            "valence": np.zeros(T),
            "arousal": np.zeros(T),
            "workspace": np.zeros((T,5)),
        }
        # create smooth baseline with tiny noise
        base = np.array([cfg.baseline_hr, cfg.baseline_hrv, cfg.baseline_eda,
                         cfg.baseline_resp, cfg.baseline_pupil], dtype=float)
        for t in range(T):
            intero = base + self.rng.normal(0, [0.5,0.5,0.02,0.2,0.05])
            # threat dynamics
            if t >= threat_time:
                k = 1.0 - min(1.0, (t - threat_time)/max(1, int(20*(0.5+control))))
                intero[0] += (18*(1.0-control))*k           # HR up
                intero[1] -= (7*(1.0-control))*k            # HRV down
                intero[2] += (0.8*novelty)*k                 # EDA up
                intero[3] += (2.0*(1.0-control))*k           # Resp up
                intero[4] += (0.3*novelty)*k                 # Pupil up
            out = self.step(intero)
            data["intero"][t] = intero
            data["valence"][t] = out["valence"]
            data["arousal"][t] = out["arousal"]
            data["workspace"][t] = out["workspace"]
        return data
