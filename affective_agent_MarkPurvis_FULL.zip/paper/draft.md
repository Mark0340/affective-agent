
# Affective Agent Prototype — Draft
**Author:** Mark Purvis

## Model Summary
We operationalize feeling as the integration of:
- **Interoception**: HR, HRV, EDA, Respiration, Pupil (synthetic)
- **Prediction error**: difference between predicted and sensed intero signals (online learning)
- **Global workspace**: salient channels (high surprise) are broadcast
- **Report**: continuous valence/arousal with human-readable summary

## Equations (informal)
- Prediction update: `pred <- (1-α) * pred + α * sensed`
- Salience: `sal = |(sensed - pred) / scale|`
- Arousal: weighted positive prediction error across channels
- Valence: goal-congruence proxy from HR(-), HRV(+), EDA(-), Resp(-), Pupil(+)

## Results (synthetic)
- Threat at t=60 produces a sharp **arousal** increase and **valence** drop, then recovery.
- Higher **control** shortens recovery time (resilience).

See figures in `figures/`:
- `arousal_threat.png`
- `valence_threat.png`
- `arousal_control_compare.png`

## Next Steps
- Add voice/face/context features for fine-grained emotions.
- Personalization adapters per individual.
- Validate on real datasets (WESAD/DEAP).
