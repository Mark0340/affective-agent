
"""
Run two simple simulations and save plots:
- Baseline to threat and recovery
- Different control levels to show resilience differences
"""
import os, numpy as np
import matplotlib.pyplot as plt
from src.affective_agent import AffectiveAgent, AgentConfig

OUT = "/mnt/data/affective_agent_project/figures"
os.makedirs(OUT, exist_ok=True)

def sim_threat(threat_time=60):
    agent = AffectiveAgent(AgentConfig())
    out = agent.run_sequence(T=120, threat_time=threat_time, novelty=0.9, control=0.3)
    # Plot arousal
    plt.figure()
    plt.plot(out["arousal"])
    plt.axvline(threat_time, linestyle="--")
    plt.title("Arousal over time (threat at t={})".format(threat_time))
    plt.xlabel("t"); plt.ylabel("arousal")
    plt.savefig(os.path.join(OUT, "arousal_threat.png"), dpi=150, bbox_inches="tight")
    plt.close()
    # Plot valence
    plt.figure()
    plt.plot(out["valence"])
    plt.axvline(threat_time, linestyle="--")
    plt.title("Valence over time (threat at t={})".format(threat_time))
    plt.xlabel("t"); plt.ylabel("valence")
    plt.savefig(os.path.join(OUT, "valence_threat.png"), dpi=150, bbox_inches="tight")
    plt.close()

def sim_control_compare():
    cfg = AgentConfig()
    agent_low = AffectiveAgent(cfg, seed=1)
    agent_high = AffectiveAgent(cfg, seed=2)
    out_low = agent_low.run_sequence(T=120, threat_time=60, novelty=0.9, control=0.2)
    out_high= agent_high.run_sequence(T=120, threat_time=60, novelty=0.9, control=0.8)
    # Plot arousal comparison
    plt.figure()
    plt.plot(out_low["arousal"], label="low control")
    plt.plot(out_high["arousal"], label="high control")
    plt.axvline(60, linestyle="--")
    plt.legend()
    plt.title("Arousal vs. control (higher control → quicker recovery)")
    plt.xlabel("t"); plt.ylabel("arousal")
    plt.savefig(os.path.join(OUT, "arousal_control_compare.png"), dpi=150, bbox_inches="tight")
    plt.close()

if __name__ == "__main__":
    sim_threat(60)
    sim_control_compare()
    print("Saved figures to:", OUT)
