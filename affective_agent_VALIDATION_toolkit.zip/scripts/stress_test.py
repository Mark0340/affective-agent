"""Stress-test: noise, missing data, and latency injection.
Saves results to results/stress_results.csv
"""
import os, numpy as np, pandas as pd
from src.affective_agent import AffectiveAgent, AgentConfig

OUT = "/mnt/data/affective_agent_project/results"
os.makedirs(OUT, exist_ok=True)

def inject_latency(x, lag):
    return np.concatenate([np.zeros(lag), x[:-lag]]) if lag>0 else x

def main():
    rows = []
    for seed in range(5):
        for noise in [0.0, 0.05, 0.1]:
            for lag in [0, 3, 8]:  # ~0, 300ms, 800ms if dt=0.1s in future
                a = AffectiveAgent(AgentConfig(), seed=seed)
                out = a.run_sequence(T=180, threat_time=80, novelty=0.7, control=0.5)
                ar = out["arousal"].copy()
                # add noise
                if noise>0:
                    ar = np.clip(ar + np.random.normal(0, noise, size=ar.shape), 0, 1)
                # add latency (shift)
                if lag>0:
                    ar = inject_latency(ar, lag)
                post = ar[80:]
                peak = float(post.max())
                # recovery simple metric: steps until <= 10% above median pre-threat
                baseline = out["arousal"][:80].mean()
                eps = max(0.03, 0.15*np.std(out["arousal"][:80]))
                rec = None
                for i in range(80, len(ar)):
                    if ar[i] <= baseline+eps:
                        rec = i-80; break
                rows.append(dict(seed=seed, noise=noise, lag=lag, peak=peak, recovery=rec))
    pd.DataFrame(rows).to_csv(os.path.join(OUT,"stress_results.csv"), index=False)
    print("Saved", os.path.join(OUT,"stress_results.csv"))

if __name__ == "__main__":
    main()
