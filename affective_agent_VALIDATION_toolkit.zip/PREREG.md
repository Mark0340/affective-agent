# Preregistration (Draft)

## Objective
Validate a computational affect model on human-like and real physiological data and demonstrate component necessity.

## Primary Metrics
- Pearson r (arousal, valence) on held-out subjects
- AUROC for high/low arousal classification
- Recovery half-life error vs. annotated events

## Thresholds
- r ≥ 0.40 (arousal), r ≥ 0.30 (valence)
- AUROC ≥ 0.75
- Recovery error ≤ 15%

## Plan
- Fixed seeds for simulation; subject-wise splits for real data
- Ablations: no learning, no workspace, fixed weights, drop EDA
- Baselines: static linear, simple smoother
- Stress: noise (σ ∈ {0, .05, .1}), latency (0, 3, 8 steps)
- Perturbation: signed channel manipulations with predicted effects

## Blind Eval
- A third party will run `repro/make_all.sh` on a held-out dataset and share only metrics.
