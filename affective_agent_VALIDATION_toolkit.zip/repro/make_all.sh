#!/usr/bin/env bash
set -e
echo "[1/6] Running simulations & figures"
python scripts/simulate.py || true
echo "[2/6] Running complexity & perturbation"
python scripts/complexity_and_perturb.py || true
echo "[3/6] Running ablations"
python scripts/ablation_study.py || true
echo "[4/6] Running baselines"
python scripts/baselines_compare.py || true
echo "[5/6] Running stress tests"
python scripts/stress_test.py || true
echo "[6/6] (Optional) Evaluate on real data - requires local dataset"
echo "Done. See results/ and experiments/."
