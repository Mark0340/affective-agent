# Repro Capsule

Run all core analyses (simulations, complexity, ablations, baselines, stress tests).

```bash
bash repro/make_all.sh
```
Results will appear in `results/` and `experiments/`.
