import pandas as pd
import numpy as np
from typing import Dict, Optional

def load_self_report_csv(path: str, t_col="t", a_col="arousal", v_col="valence") -> Dict[str, np.ndarray]:
    df = pd.read_csv(path)
    for c in [t_col, a_col, v_col]:
        if c not in df.columns:
            raise ValueError(f"Missing column: {c}")
    return {
        "t": df[t_col].to_numpy(),
        "arousal": df[a_col].to_numpy(),
        "valence": df[v_col].to_numpy(),
    }

def load_events_csv(path: str, t_start_col="t_start", t_end_col="t_end", label_col="label") -> pd.DataFrame:
    df = pd.read_csv(path)
    for c in [t_start_col, t_end_col, label_col]:
        if c not in df.columns:
            raise ValueError(f"Missing column: {c}")
    return df[[t_start_col, t_end_col, label_col]].rename(columns={t_start_col:"t_start", t_end_col:"t_end", label_col:"label"})
