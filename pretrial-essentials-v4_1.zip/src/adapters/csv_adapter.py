import numpy as np, pandas as pd
from typing import Dict, Optional

def load_physio_csv(path: str,
                    eda_col: str="eda",
                    hr_col: str="hr",
                    resp_col: str="resp",
                    t_col: Optional[str]=None,
                    sampling_hz: float=10.0) -> Dict[str, np.ndarray]:
    df = pd.read_csv(path)
    for c in [eda_col, hr_col, resp_col]:
        if c not in df.columns:
            raise ValueError(f"Missing column: {c}")
    eda = df[eda_col].to_numpy()
    hr = df[hr_col].to_numpy()
    resp = df[resp_col].to_numpy()
    if t_col and t_col in df.columns:
        t = df[t_col].to_numpy()
    else:
        N = len(eda)
        t = np.arange(N)/float(sampling_hz)
    return {"t": t, "eda": eda, "hr": hr, "resp": resp}
