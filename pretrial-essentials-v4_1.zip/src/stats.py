import numpy as np
from typing import Tuple

def bootstrap_ci(values: np.ndarray, iters: int=5000, alpha: float=0.05, rng=None) -> Tuple[float,float,float]:
    rng = np.random.default_rng() if rng is None else rng
    values = np.asarray(values, dtype=float)
    boots = np.empty(iters, dtype=float)
    n = len(values)
    for i in range(iters):
        idx = rng.integers(0, n, n)
        boots[i] = np.nanmean(values[idx])
    return float(np.nanmean(values)), float(np.nanpercentile(boots, 100*alpha/2)), float(np.nanpercentile(boots, 100*(1-alpha/2)))

def permutation_test(x: np.ndarray, y: np.ndarray, iters: int=10000, metric="mean_diff", rng=None) -> float:
    rng = np.random.default_rng() if rng is None else rng
    x = np.asarray(x, float); y = np.asarray(y, float)
    if metric == "mean_diff":
        obs = np.nanmean(x) - np.nanmean(y)
        pooled = np.concatenate([x, y])
        count = 0
        for _ in range(iters):
            rng.shuffle(pooled)
            xp = pooled[:len(x)]; yp = pooled[len(x):]
            if abs(np.nanmean(xp) - np.nanmean(yp)) >= abs(obs):
                count += 1
        return float((count+1)/(iters+1))
    raise ValueError("Unknown metric")

def permutation_one_sample_zero(values: np.ndarray, iters: int=10000, rng=None) -> float:
    rng = np.random.default_rng() if rng is None else rng
    x = np.asarray(values, float)
    obs = np.nanmean(x)
    count = 0
    for _ in range(iters):
        signs = rng.choice([-1.0, 1.0], size=len(x))
        xp = x * signs
        if abs(np.nanmean(xp)) >= abs(obs):
            count += 1
    return float((count+1)/(iters+1))

def fisher_z_ci(corr_values: np.ndarray, alpha: float=0.05):
    from scipy.stats import norm
    x = np.asarray(corr_values, float)
    x = x[~np.isnan(x)]
    if len(x) == 0:
        return (float('nan'), float('nan'), float('nan'))
    z = np.arctanh(np.clip(x, -0.999999, 0.999999))
    z_mean = np.nanmean(z)
    se = 1/np.sqrt(max(1, len(x)-3))
    z_lo = z_mean + norm.ppf(alpha/2)*se
    z_hi = z_mean + norm.ppf(1-alpha/2)*se
    return (float(np.tanh(z_mean)), float(np.tanh(z_lo)), float(np.tanh(z_hi)))
