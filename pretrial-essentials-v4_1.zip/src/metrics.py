import numpy as np
from typing import Tuple

def _discretize(x: np.ndarray, bins: int = 32) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    hist_edges = np.linspace(np.nanmin(x), np.nanmax(x)+1e-12, bins+1)
    # handle constant signal
    if np.nanmax(x) - np.nanmin(x) < 1e-12:
        return np.zeros_like(x, dtype=int)
    return np.clip(np.digitize(x, hist_edges[:-1], right=False) - 1, 0, bins-1)

def shannon_entropy(x: np.ndarray, bins: int = 32, base: float = np.e) -> float:
    """Discretize x and compute Shannon entropy of the empirical distribution.
    Returns entropy in 'base' units (nats by default)."""
    x = np.asarray(x, dtype=float)
    q = _discretize(x, bins)
    counts = np.bincount(q, minlength=bins).astype(float)
    p = counts / (counts.sum() + 1e-12)
    nz = p[p > 0]
    H = -np.sum(nz * np.log(nz) / np.log(base))
    return float(H)

def lz76_complexity(x: np.ndarray, bins: int = 32) -> float:
    """Lempel-Ziv 76 complexity on a discretized sequence.
    Returns the number of distinct phrases (higher => more complex)."""
    s = _discretize(np.asarray(x), bins).astype(int).tolist()
    # convert ints to bytes-like string for factorization
    s_str = ",".join(map(str, s))
    i, k, l = 0, 1, 1
    c = 1
    n = len(s_str)
    while True:
        if i + k <= n and s_str[i:i+k] == s_str[l:l+k]:
            k += 1
            if l + k > n:
                c += 1
                break
        else:
            if k == 1:
                c += 1
                l += 1
                if l > n:
                    break
            else:
                i += 1
                if i == l:
                    c += 1
                    l += k
                    if l > n:
                        break
                    i = 0
                k = 1
        if l >= n:
            break
    return float(c)

def active_information_storage(x: np.ndarray, k: int = 1, bins: int = 16, base: float = np.e) -> float:
    """Very simple AIS estimator for discrete time series:
    AIS = I(X_t ; X_{t-1..t-k}). This uses plug-in MI with discretization.
    Not suitable for publication-grade values, but useful for regression tests.
    """
    x = np.asarray(x, dtype=float)
    if len(x) <= k + 1:
        return 0.0
    xd = _discretize(x, bins)
    X = xd[k:]
    P = np.column_stack([xd[i:len(xd)-(k-i)] for i in range(k)])
    # joint frequencies
    # pack parent vectors into single labels
    parent_base = (bins ** np.arange(k)).astype(int)
    parents = (P * parent_base).sum(axis=1)
    # compute entropies
    HX = _entropy_from_counts(np.bincount(X, minlength=bins), base)
    HP = _entropy_from_counts(np.bincount(parents), base)
    HXP = _entropy_from_counts(_joint_counts(X, parents), base)
    I = HX + HP - HXP
    return float(max(0.0, I))

def _entropy_from_counts(counts: np.ndarray, base: float) -> float:
    counts = counts.astype(float)
    p = counts / (counts.sum() + 1e-12)
    nz = p[p > 0]
    return float(-np.sum(nz * np.log(nz) / np.log(base)))

def _joint_counts(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a = a.astype(int); b = b.astype(int)
    ab = a.max()+1
    code = a + ab * b
    m = code.max()+1
    return np.bincount(code, minlength=m)

def summary_metrics(arousal: np.ndarray, valence: np.ndarray, *, bins:int=32, ais_k:int=1, ais_bins:int=16) -> dict:
    H = shannon_entropy(arousal, bins=bins)
    LZ = lz76_complexity(arousal, bins=bins)
    AIS = active_information_storage(arousal, k=ais_k, bins=ais_bins)
    return {
        "entropy": float(H),
        "lz_complexity": float(LZ),
        "ais": float(AIS),
        "arousal_mean": float(np.mean(arousal)),
        "valence_mean": float(np.mean(valence)),
    }
