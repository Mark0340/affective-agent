import numpy as np
from typing import Optional

def rmssd_from_rr(rr_ms: np.ndarray) -> float:
    rr = np.asarray(rr_ms, dtype=float)
    if len(rr) < 3: 
        return float('nan')
    diff = np.diff(rr)
    return float(np.sqrt(np.nanmean(diff*diff)))

def rmssd_from_hr(hr_bpm: np.ndarray, sampling_hz: float = 10.0) -> float:
    # Approximate RR from HR: RR (ms) ~ 60000 / HR (bpm), then compute RMSSD on a resampled sequence
    hr = np.asarray(hr_bpm, dtype=float)
    rr_ms = 60000.0 / np.clip(hr, 1e-3, None)
    # downsample to 4Hz equivalent to reduce serial correlation bias
    step = max(1, int(sampling_hz/4.0))
    rr_ms_ds = rr_ms[::step]
    return rmssd_from_rr(rr_ms_ds)
