import numpy as np
from dataclasses import dataclass
from typing import Dict

@dataclass
class TaskDesign:
    sampling_hz: int = 10
    baseline_s: int = 60
    stress_s: int = 120
    recovery_s: int = 180

def synthetic_signals(design: TaskDesign, noise_std: float = 0.02, seed: int = 1337) -> Dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    T = design.baseline_s + design.stress_s + design.recovery_s
    steps = T * design.sampling_hz
    t = np.linspace(0, T, steps)

    # baseline components
    eda_base = 0.5 + 0.03*np.sin(0.1*t)
    hr_base = 70 + 2*np.sin(0.03*t + 0.2)
    resp_base = 12 + 2*np.sin(2*np.pi*0.25*t)

    # perturbation mask: stress block
    stress_mask = (t >= design.baseline_s) & (t < design.baseline_s + design.stress_s)
    recovery_mask = (t >= design.baseline_s + design.stress_s)

    # stress: EDA up, HR up, respiration irregular
    eda = eda_base + 0.25*stress_mask.astype(float) + rng.normal(0, noise_std, size=steps)
    hr = hr_base + 5*stress_mask.astype(float) + rng.normal(0, noise_std*10, size=steps)
    resp = resp_base + 0.5*stress_mask.astype(float) - 1.0*recovery_mask.astype(float) + rng.normal(0, noise_std, size=steps)

    return { "t": t, "eda": eda, "hr": hr, "resp": resp, "stress_mask": stress_mask.astype(int), "recovery_mask": recovery_mask.astype(int) }
