import numpy as np
from dataclasses import dataclass
from typing import Dict, Tuple

@dataclass
class QCConfig:
    eda_min: float = 0.0
    eda_max: float = 10.0
    hr_min: float = 35.0
    hr_max: float = 200.0
    resp_min: float = 2.0
    resp_max: float = 40.0
    max_nan_frac: float = 0.3

def basic_qc(sig: Dict[str, np.ndarray], cfg: QCConfig = QCConfig()) -> Tuple[Dict[str, np.ndarray], Dict[str, float]]:
    out = {k: np.copy(v) for k, v in sig.items() if k in ("t","eda","hr","resp")}
    stats = {}
    # Clip out-of-range
    out["eda"] = np.clip(out["eda"], cfg.eda_min, cfg.eda_max)
    out["hr"] = np.clip(out["hr"], cfg.hr_min, cfg.hr_max)
    out["resp"] = np.clip(out["resp"], cfg.resp_min, cfg.resp_max)
    # NaN handling
    for k in ["eda","hr","resp"]:
        nans = np.isnan(out[k]).sum()
        stats[f"{k}_nan_frac"] = float(nans/len(out[k]))
        if nans > 0:
            # simple forward-fill then back-fill
            arr = out[k]
            idx = np.where(~np.isnan(arr))[0]
            if len(idx) == 0:
                continue
            for i in range(1,len(arr)):
                if np.isnan(arr[i]): arr[i] = arr[i-1]
            for i in range(len(arr)-2, -1, -1):
                if np.isnan(arr[i]): arr[i] = arr[i+1]
    # Dropout metric: successive equal values (flatline) proportion
    for k in ["eda","hr","resp"]:
        eq = np.sum(np.diff(out[k]) == 0)
        stats[f"{k}_flat_frac"] = float(eq / max(1,len(out[k])-1))
    return out, stats
