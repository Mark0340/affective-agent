import numpy as np
from dataclasses import dataclass
from typing import Dict

@dataclass
class AffectiveAgentConfig:
    intero_gain: float = 1.0
    pe_gain: float = 0.5
    gw_integration: float = 0.9  # smoothing for global broadcast (0..1)
    valence_weight_eda: float = -0.8
    valence_weight_resp: float = 0.05
    arousal_weight_eda: float = 1.0
    arousal_weight_hr: float = 0.01

class AffectiveAgent:
    def __init__(self, cfg: AffectiveAgentConfig):
        self.cfg = cfg
        self._gw_a = 0.0
        self._gw_v = 0.0

    @classmethod
    def from_defaults(cls):
        return cls(AffectiveAgentConfig())

    def step(self, eda: float, hr: float, resp: float) -> Dict[str, float]:
        # Interoceptive prediction (running means as proxy)
        # PE = signal - running mean
        alpha = 0.01
        if not hasattr(self, "_m_eda"):
            self._m_eda, self._m_hr, self._m_resp = eda, hr, resp
        self._m_eda = (1-alpha)*self._m_eda + alpha*eda
        self._m_hr = (1-alpha)*self._m_hr + alpha*hr
        self._m_resp = (1-alpha)*self._m_resp + alpha*resp

        pe_eda = eda - self._m_eda
        pe_hr = hr - self._m_hr
        pe_resp = resp - self._m_resp

        # Map to latent arousal/valence before GW broadcast
        a = self.cfg.arousal_weight_eda * pe_eda + self.cfg.arousal_weight_hr * pe_hr
        v = self.cfg.valence_weight_eda * pe_eda + self.cfg.valence_weight_resp * pe_resp

        # Global workspace broadcast (leaky integration)
        self._gw_a = self.cfg.gw_integration*self._gw_a + (1-self.cfg.gw_integration)*a
        self._gw_v = self.cfg.gw_integration*self._gw_v + (1-self.cfg.gw_integration)*v

        return {"arousal": self._gw_a, "valence": self._gw_v}

    def run(self, sig: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        arousal = np.zeros_like(sig["eda"])
        valence = np.zeros_like(sig["eda"])
        for i in range(len(arousal)):
            out = self.step(float(sig["eda"][i]), float(sig["hr"][i]), float(sig["resp"][i]))
            arousal[i] = out["arousal"]
            valence[i] = out["valence"]
        return {"arousal": arousal, "valence": valence}
