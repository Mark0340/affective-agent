import numpy as np
from src.metrics import shannon_entropy, lz76_complexity, active_information_storage, summary_metrics

def test_entropy_bounds_constant_signal():
    x = np.zeros(1000)
    H = shannon_entropy(x, bins=8)
    assert H == 0.0

def test_lz_increases_with_variability():
    a = np.zeros(200)
    b = np.random.RandomState(0).randn(200)
    assert lz76_complexity(b, bins=8) >= lz76_complexity(a, bins=8)

def test_ais_nonnegative():
    x = np.sin(np.linspace(0, 6.28, 1000))
    ais = active_information_storage(x, k=1, bins=8)
    assert ais >= 0.0

def test_summary_metrics_keys():
    x = np.random.RandomState(0).randn(500)
    m = summary_metrics(x, x)
    for k in ["entropy","lz_complexity","ais","arousal_mean","valence_mean"]:
        assert k in m
