import numpy as np
from src.qc import basic_qc, QCConfig
from src.metrics import shannon_entropy

def test_qc_nan_fill_and_clip():
    sig = {"t": np.arange(10)/10.0,
           "eda": np.array([np.nan, -1, 0.1, 0.2, 20, 0.3, 0.3, 0.3, 0.4, 0.5], dtype=float),
           "hr":  np.array([30, 40, 50, 60, 210, 70, 70, 70, 80, 90], dtype=float),
           "resp":np.array([1, 3, 4, 50, 10, 12, 12, 12, 15, np.nan], dtype=float)}
    cleaned, stats = basic_qc(sig, QCConfig())
    assert stats["eda_nan_frac"] > 0.0
    assert cleaned["eda"].min() >= 0.0 and cleaned["eda"].max() <= 10.0
    assert cleaned["hr"].min() >= 35.0 and cleaned["hr"].max() <= 200.0

def test_entropy_monotonicity_with_bins():
    x = np.zeros(1000)
    H1 = shannon_entropy(x, bins=8)
    H2 = shannon_entropy(np.r_[x, np.random.RandomState(0).randn(1000)], bins=8)
    assert H1 <= H2
