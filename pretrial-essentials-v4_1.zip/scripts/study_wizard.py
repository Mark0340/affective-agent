#!/usr/bin/env python3
import argparse
from pathlib import Path
import json, shutil

TEMPLATE = {
  "study_name": "pilot01",
  "subjects": ["S001","S002"],
  "sessions_per_subject": 1,
  "expected_columns": {"eda":"eda", "hr":"hr", "resp":"resp", "t":"t"}
}

def init_study(root: Path, name: str):
    root.mkdir(parents=True, exist_ok=True)
    (root/"raw").mkdir(exist_ok=True)
    (root/"derivatives").mkdir(exist_ok=True)
    (root/"code").mkdir(exist_ok=True)
    (root/"notes").mkdir(exist_ok=True)
    with (root/"study.json").open("w") as f:
        json.dump(TEMPLATE | {"study_name": name}, f, indent=2)
    print(f"✔ Created study at {root}")

def add_subjects(root: Path, subjects):
    for s in subjects:
        (root/"raw"/s).mkdir(parents=True, exist_ok=True)
        print(f"✔ Subject folder: {s}")

def anonymize_copy(src_file: Path, dst_dir: Path, subject: str):
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / f"{subject}.csv"
    shutil.copy(src_file, dst)
    print(f"✔ Copied/anonymized to {dst}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["init","add_subjects","anon_copy"])
    ap.add_argument("--root", default="study")
    ap.add_argument("--name", default="pilot01")
    ap.add_argument("--subjects", nargs="*", default=["S001","S002"])
    ap.add_argument("--src", default="")
    ap.add_argument("--dest", default="study/raw/S001")
    args = ap.parse_args()

    root = Path(args.root)
    if args.cmd == "init":
        init_study(root, args.name)
    elif args.cmd == "add_subjects":
        add_subjects(root, args.subjects)
    elif args.cmd == "anon_copy":
        anonymize_copy(Path(args.src), Path(args.dest), Path(args.dest).name)

if __name__ == "__main__":
    main()
