#!/usr/bin/env python3
import argparse
import pandas as pd
import numpy as np
from pathlib import Path

def load_markers(path: str):
    df = pd.read_csv(path)
    if {"t","label"}.issubset(df.columns):
        m = df[["t","label"]].copy()
    elif {"t","value"}.issubset(df.columns):
        m = df[["t","value"]].copy().rename(columns={"value":"label"})
    else:
        raise SystemExit("Marker CSV must have columns (t,label) or (t,value).")
    return m.sort_values("t").reset_index(drop=True)

def infer_blocks(markers: pd.DataFrame, labels=("baseline","stress","recovery"),
                 durations=(120,120,300)) -> pd.DataFrame:
    t0 = float(markers["t"].min()) if len(markers) else 0.0
    t_bounds = [t0]
    for d in durations:
        t_bounds.append(t_bounds[-1] + float(d))
    rows = []
    for i, lab in enumerate(labels):
        rows.append({"t_start": t_bounds[i], "t_end": t_bounds[i+1], "label": lab})
    return pd.DataFrame(rows)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--markers_csv", required=True)
    ap.add_argument("--out_events_csv", required=True)
    ap.add_argument("--baseline", default="baseline")
    ap.add_argument("--stress", default="stress")
    ap.add_argument("--recovery", default="recovery")
    ap.add_argument("--durations", default="120,120,300")
    args = ap.parse_args()

    m = load_markers(args.markers_csv)
    labels = (args.baseline, args.stress, args.recovery)
    durations = tuple(float(x) for x in args.durations.split(","))

    rows = []
    for lab in labels:
        hits = m[m["label"].str.contains(lab, case=False, na=False)]
        if len(hits) >= 2:
            rows.append({"t_start": float(hits.iloc[0]["t"]),
                         "t_end": float(hits.iloc[1]["t"]),
                         "label": lab})
    ev = pd.DataFrame(rows) if len(rows) == 3 else infer_blocks(m, labels=labels, durations=durations)
    Path(args.out_events_csv).parent.mkdir(parents=True, exist_ok=True)
    ev.to_csv(args.out_events_csv, index=False)
    print(f"✔ Wrote events CSV to {args.out_events_csv}")

if __name__ == "__main__":
    main()
