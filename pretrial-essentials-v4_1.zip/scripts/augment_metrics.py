#!/usr/bin/env python3
import argparse
from pathlib import Path
import pandas as pd
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
import numpy as np

from src.adapters.self_report import load_self_report_csv, load_events_csv
from src.adapters.csv_adapter import load_physio_csv

def nearest_align(t_ref, t_query):
    t_ref = np.asarray(t_ref)
    idx = np.searchsorted(t_ref, t_query)
    idx = np.clip(idx, 0, len(t_ref)-1)
    idx_minus = np.clip(idx-1, 0, len(t_ref)-1)
    choose_prev = np.abs(t_query - t_ref[idx_minus]) < np.abs(t_query - t_ref[idx])
    idx[choose_prev] = idx_minus[choose_prev]
    return idx

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", required=True, help="Path to an existing runs/<timestamp> directory")
    ap.add_argument("--data_csv", required=True, help="CSV used for this run (or a copy with same columns)")
    ap.add_argument("--events_csv", default="")
    ap.add_argument("--self_report_csv", default="")
    ap.add_argument("--eda_col", default="eda")
    ap.add_argument("--hr_col", default="hr")
    ap.add_argument("--resp_col", default="resp")
    ap.add_argument("--t_col", default="")
    ap.add_argument("--sampling_hz", type=float, default=10.0)
    ap.add_argument("--self_report_t", default="t")
    ap.add_argument("--self_report_arousal", default="arousal")
    ap.add_argument("--self_report_valence", default="valence")
    args = ap.parse_args()

    run_dir = Path(args.run_dir)
    metrics_csv = run_dir / "metrics.csv"
    if not metrics_csv.exists():
        raise SystemExit(f"metrics.csv not found in {run_dir}")

    sig = load_physio_csv(args.data_csv, eda_col=args.eda_col, hr_col=args.hr_col, resp_col=args.resp_col,
                          t_col=(args.t_col or None), sampling_hz=args.sampling_hz)
    t = sig["t"]

    additions = []
    run_id = run_dir.name

    z = lambda x: (x - np.nanmean(x)) / (np.nanstd(x) + 1e-8)
    A = z(sig["eda"]) + 0.01*z(sig["hr"])
    V = -0.8*z(sig["eda"]) + 0.05*z(sig["resp"])

    if args.events_csv:
        ev = load_events_csv(args.events_csv)
        def seg_mean(arr, start, end):
            m = (t >= start) & (t < end)
            return float(np.nanmean(arr[m])) if m.any() else np.nan
        labels = {row.label: (row.t_start, row.t_end) for _, row in ev.iterrows()}
        if all(k in labels for k in ["baseline","stress","recovery"]):
            A_base = seg_mean(A, *labels["baseline"])
            A_stress = seg_mean(A, *labels["stress"])
            A_rec = seg_mean(A, *labels["recovery"])
            V_base = seg_mean(V, *labels["baseline"])
            V_stress = seg_mean(V, *labels["stress"])
            V_rec = seg_mean(V, *labels["recovery"])
            additions += [
                ("delta_arousal_stress_minus_base", A_stress - A_base, "events"),
                ("delta_arousal_rec_minus_stress", A_rec - A_stress, "events"),
                ("delta_valence_stress_minus_base", V_stress - V_base, "events"),
                ("delta_valence_rec_minus_stress", V_rec - V_stress, "events"),
            ]

    if args.self_report_csv:
        sr = load_self_report_csv(args.self_report_csv, t_col=args.self_report_t,
                                  a_col=args.self_report_arousal, v_col=args.self_report_valence)
        idx = nearest_align(t, sr["t"])
        corrA = np.corrcoef(A[idx], sr["arousal"])[0,1] if len(idx) > 1 else np.nan
        corrV = np.corrcoef(V[idx], sr["valence"])[0,1] if len(idx) > 1 else np.nan
        additions += [
            ("corr_selfreport_arousal", float(corrA), "self_report"),
            ("corr_selfreport_valence", float(corrV), "self_report"),
        ]

    if additions:
        with metrics_csv.open("a") as f:
            for metric, value, notes in additions:
                f.write(f"{run_id},baseline,0,{metric},{value},0,{notes}\n")

    print(f"✔ Augmented {metrics_csv} with {len(additions)} metrics")

if __name__ == "__main__":
    main()
