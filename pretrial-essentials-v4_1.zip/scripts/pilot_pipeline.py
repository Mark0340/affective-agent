#!/usr/bin/env python3
import argparse, subprocess, sys
from pathlib import Path

def run(cmd):
    print(">", " ".join(cmd)); subprocess.run(cmd, check=True)

def main():
    p = argparse.ArgumentParser(description="One-shot: augment metrics -> build report -> build PDF")
    p.add_argument("--run_dir", required=True)
    p.add_argument("--data_csv", required=True)
    p.add_argument("--events_csv", default="")
    p.add_argument("--self_report_csv", default="")
    p.add_argument("--summary_md", default="docs/validation_summary.md")
    p.add_argument("--pdf_out", default="docs/affective-agent_pilot_report.pdf")
    args = p.parse_args()

    # Augment
    run([sys.executable, "scripts/augment_metrics.py",
         "--run_dir", args.run_dir,
         "--data_csv", args.data_csv,
         *(["--events_csv", args.events_csv] if args.events_csv else []),
         *(["--self_report_csv", args.self_report_csv] if args.self_report_csv else [])
    ])

    # Report
    run([sys.executable, "scripts/validation_report.py", "--runs", "runs", "--out", args.summary_md])

    # PDF
    run([sys.executable, "scripts/build_pilot_pdf.py", "--out", args.pdf_out])

if __name__ == "__main__":
    main()
