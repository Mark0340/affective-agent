#!/usr/bin/env python3
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import textwrap, argparse

def add_text_page(pdf, title, body, fontsize=11):
    fig = plt.figure(figsize=(8.5, 11))
    fig.suptitle(title, fontsize=16, y=0.98)
    wrapper = textwrap.TextWrapper(width=95)
    lines = []
    for para in body.split("\n"):
        if not para.strip():
            lines.append("")
        else:
            lines.extend(wrapper.wrap(para))
    fig.text(0.06, 0.92, "\n".join(lines), fontsize=fontsize, va="top")
    plt.axis('off')
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="docs/affective-agent_pilot_report.pdf")
    ap.add_argument("--summary_md", default="docs/validation_summary.md")
    ap.add_argument("--prereg_md", default="docs/prereg/preregistration_outline.md")
    ap.add_argument("--consent_md", default="docs/prereg/consent_template.md")
    ap.add_argument("--operator_md", default="docs/operator_runbook.md")
    ap.add_argument("--fig_dir", default="runs/figures")
    args = ap.parse_args()

    base = Path(".")
    summary_md = Path(args.summary_md).read_text() if Path(args.summary_md).exists() else "# Validation Summary\n(No content found)"
    prereg_md = Path(args.prereg_md).read_text() if Path(args.prereg_md).exists() else ""
    operator_md = Path(args.operator_md).read_text() if Path(args.operator_md).exists() else ""
    consent_md = Path(args.consent_md).read_text() if Path(args.consent_md).exists() else ""

    fig_dir = Path(args.fig_dir)
    entropy_png = fig_dir/"entropy_by_condition.png"
    ais_png = fig_dir/"ais_by_condition.png"

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with PdfPages(out) as pdf:
        cover = plt.figure(figsize=(8.5, 11))
        cover.text(0.5, 0.7, "Affective Agent — Pilot Validation Report", ha="center", va="center", fontsize=22)
        cover.text(0.5, 0.64, "Pre‑Human‑Trials Package (v0.9.0-pretrial)", ha="center", va="center", fontsize=14)
        cover.text(0.5, 0.58, "Consolidated validation summary, figures, prereg outline,\noperator runbook, and consent template.", ha="center", va="center", fontsize=11)
        plt.axis('off')
        pdf.savefig(cover, bbox_inches="tight")
        plt.close(cover)

        add_text_page(pdf, "Validation Summary", summary_md)

        if entropy_png.exists():
            fig = plt.figure(figsize=(8.5, 11))
            img = plt.imread(str(entropy_png))
            plt.imshow(img); plt.axis('off'); plt.title("Entropy by Condition")
            pdf.savefig(fig, bbox_inches="tight"); plt.close(fig)
        if ais_png.exists():
            fig = plt.figure(figsize=(8.5, 11))
            img = plt.imread(str(ais_png))
            plt.imshow(img); plt.axis('off'); plt.title("AIS by Condition")
            pdf.savefig(fig, bbox_inches="tight"); plt.close(fig)

        if prereg_md: add_text_page(pdf, "Preregistration Outline", prereg_md)
        if operator_md: add_text_page(pdf, "Operator Runbook", operator_md)
        if consent_md: add_text_page(pdf, "Participant Consent (Template)", consent_md)

    print(f"✔ Wrote {out}")

if __name__ == "__main__":
    main()
