import pandas as pd
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
import argparse
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
from src.stats import bootstrap_ci, permutation_test, permutation_one_sample_zero, fisher_z_ci

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    runs_dir = Path(args.runs)
    metrics_files = sorted(runs_dir.glob("*/metrics.csv"))
    if not metrics_files:
        Path(args.out).write_text("# Validation Summary\n\nNo runs found.")
        return

    df = pd.concat([pd.read_csv(f) for f in metrics_files], ignore_index=True)

    # Headline: entropy and AIS per run
    ent = df[df.metric=="entropy"][["run_id","value"]].copy()
    ent["label"] = ent["run_id"].str.extract(r'^\d{8}-\d{6}_(.+?)_seed')
    ent = ent.sort_values("label")

    ais = df[df.metric=="ais"][["run_id","value"]].copy()
    ais["label"] = ais["run_id"].str.extract(r'^\d{8}-\d{6}_(.+?)_seed')
    ais = ais.sort_values("label")

    # Group into baseline vs ablations for a permutation comparison
    def is_ablation(lbl): return lbl.startswith("ablate_")
    base_vals = ent[~ent["label"].apply(is_ablation)]["value"].to_numpy()
    abl_vals = ent[ent["label"].apply(is_ablation)]["value"].to_numpy()
    p_perm = permutation_test(base_vals, abl_vals) if len(base_vals)>0 and len(abl_vals)>0 else np.nan

    # Bootstrap CI for entropy means
    mean_ent, lo_ent, hi_ent = bootstrap_ci(ent["value"].to_numpy())

    # Plot figures
    fig_dir = runs_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)

    plt.figure()
    plt.bar(ent["label"], ent["value"])
    plt.xticks(rotation=45, ha="right")
    plt.title("Entropy by Condition")
    plt.tight_layout()
    ent_fig = fig_dir / "entropy_by_condition.png"
    plt.savefig(ent_fig)

    plt.figure()
    plt.bar(ais["label"], ais["value"])
    plt.xticks(rotation=45, ha="right")
    plt.title("AIS by Condition")
    plt.tight_layout()
    ais_fig = fig_dir / "ais_by_condition.png"
    plt.savefig(ais_fig)

    # Optional: self-report correlations
    corrA = df[df.metric=="corr_selfreport_arousal"][["run_id","value"]]
    corrV = df[df.metric=="corr_selfreport_valence"][["run_id","value"]]
    # Optional: event deltas
    dA_SB = df[df.metric=="delta_arousal_stress_minus_base"][["run_id","value"]]
    dA_RS = df[df.metric=="delta_arousal_rec_minus_stress"][["run_id","value"]]
    dV_SB = df[df.metric=="delta_valence_stress_minus_base"][["run_id","value"]]
    dV_RS = df[df.metric=="delta_valence_rec_minus_stress"][["run_id","value"]]

    md = []
    md += ["# Validation Summary", ""]
    md += [f"- Runs aggregated: **{len(metrics_files)}**"]
    md += [f"- Entropy mean (bootstrap 95% CI): **{mean_ent:.3f} [{lo_ent:.3f}, {hi_ent:.3f}]**"]
    if not np.isnan(p_perm):
        md += [f"- Permutation test (entropy, baseline vs ablations): **p = {p_perm:.4f}**"]
    md += ["", "## Figures", "", f"![Entropy](figures/{ent_fig.name})", f"![AIS](figures/{ais_fig.name})"]
    if not corrA.empty or not corrV.empty:
        md += ["", "## Self-report Correlations", ""]
        if not corrA.empty:
            md += [f"- corr(arousal_est, arousal_self): **{corrA.value.mean():.3f}**"]
        if not corrV.empty:
            md += [f"- corr(valence_est, valence_self): **{corrV.value.mean():.3f}**"]
    if not dA_SB.empty:
        md += [f"- Δ Arousal (stress−base): **{dA_SB.value.mean():.3f}**"]
    if not dA_RS.empty:
        md += [f"- Δ Arousal (recovery−stress): **{dA_RS.value.mean():.3f}**"]
    if not dV_SB.empty:
        md += [f"- Δ Valence (stress−base): **{dV_SB.value.mean():.3f}**"]
    if not dV_RS.empty:
        md += [f"- Δ Valence (recovery−stress): **{dV_RS.value.mean():.3f}**"]
    md += ["", "## Notes", "- Replace the reference agent with your production agent to validate on real data."]
    Path(args.out).write_text("\n".join(md))
# Also write a machine-readable CSV summary with selected metrics
summary_csv = Path("docs") / "summary.csv"
rows = []
for metric in ["entropy","ais","rmssd","corr_selfreport_arousal","corr_selfreport_valence",
               "delta_arousal_stress_minus_base","delta_arousal_rec_minus_stress",
               "delta_valence_stress_minus_base","delta_valence_rec_minus_stress"]:
    sub = df[df.metric==metric][["run_id","value"]]
    if not sub.empty:
        for _, row in sub.iterrows():
            rows.append({"metric": metric, "run_id": row.run_id, "value": row.value})
import pandas as _pd
_pd.DataFrame(rows).to_csv(summary_csv, index=False)


if __name__ == "__main__":
    main()
