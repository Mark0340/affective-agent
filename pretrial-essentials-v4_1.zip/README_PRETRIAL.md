# Affective Agent — Pre‑Trials Package (v0.9.0-pretrial)

This package is prepared so the only remaining step is a **light pilot human trial** (IRB + data collection).

## Quick Start
```bash
pip install -e .
make reproduce
```

Outputs will be written under `runs/…` and a consolidated `docs/validation_summary.md` is generated.

## Structure
- `src/affective_agent.py` — simple reference implementation (interoception + prediction error + global workspace)
- `src/metrics.py` — entropy, LZ76, AIS
- `src/sim.py` — synthetic sensors + perturbation/recovery task schedule
- `scripts/experiment_runner.py` — unified runner (CLI)
- `scripts_run_from_config.py` — run YAML configs
- `scripts/validation_report.py` — aggregate `runs/*/metrics.csv` into a markdown report with figures
- `configs/*` — baseline, ablations, noise sweeps
- `tests/*` — sanity tests
- `docs/prereg/*` — prereg outline and consent templates
- `Dockerfile` — `docker build -t affective-agent .` then `docker run affective-agent`

## Next Integration Step
Replace the reference agent with your production agent while preserving the same outputs (`arousal`, `valence`) and the `metrics.csv` schema.
