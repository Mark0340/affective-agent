Affective Agent — Pre-Human-Trials Package (v4.1)

This is the packaged release bundle.
