# Operator Runbook — Pilot Human Trial (Minimal Risk)

## Before session
- Print consent form, confirm inclusion/exclusion criteria (no cardiac conditions, etc.).
- Calibrate sensors (EDA sites, PPG/ECG, respiration belt). Record 2-min baseline.
- Open stimulus script (tones or mental math) and timer.

## During session (approx 10–12 min)
1. Baseline 2 min (quiet).
2. Stress 2 min (tones or arithmetic).
3. Recovery 5 min (paced breathing ~0.1 Hz).
4. Self-report SAM ratings at Baseline end, Stress end, Recovery end.

## After session
- Export CSV with columns: `t, eda, hr, resp` (or map via CLI flags).
- Run ingestion + analysis:
```bash
python scripts/experiment_runner.py --run_name S001_session1   --data_csv path/to/export.csv --eda_col EDA --hr_col HR --resp_col RESP --sampling_hz 10
python scripts/validation_report.py --runs runs --out docs/validation_summary.md
```
- Archive raw CSV under `study/raw/S001` (use `scripts/study_wizard.py anon_copy`).

## Troubleshooting
- Flatlines or missing channels → re-seat sensors; ensure sampling rate is correct.
- Excess motion artifacts → repeat baseline or extend recovery.
