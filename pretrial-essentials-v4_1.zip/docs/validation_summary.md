# Validation Summary

- Runs aggregated: **23**
- Entropy mean (bootstrap 95% CI): **-119.403 [-271.501, -9.330]**
- Permutation test (entropy, baseline vs ablations): **p = 0.0626**

## Figures

![Entropy](figures/entropy_by_condition.png)
![AIS](figures/ais_by_condition.png)

## Self-report Correlations

- corr(arousal_est, arousal_self): **-0.782**
- corr(valence_est, valence_self): **-0.687**
- Δ Arousal (stress−base): **0.019**
- Δ Arousal (recovery−stress): **0.016**
- Δ Valence (stress−base): **-0.025**
- Δ Valence (recovery−stress): **-0.008**

## Notes
- Replace the reference agent with your production agent to validate on real data.