# Participant Information and Consent (Template)

**Study Title:** Validation of an Affective Agent using noninvasive physiological signals  
**Principal Investigator:** <Your Name>  
**Purpose:** Evaluate whether the agent’s arousal/valence estimates align with self-report and physiology.  
**Procedures:** Baseline (2–5 min), brief stress task (≤2 min), guided recovery (5 min).  
**Risks:** Minimal (brief startle or mental arithmetic).  
**Benefits:** None direct; contributes to science.  
**Confidentiality:** Pseudonymized IDs; de‑identified analyses.  
**Voluntary:** Participation is voluntary; you may withdraw at any time.  
**Contact:** <Institution contact / IRB>  

By signing, you consent to participate.  
(Signature) ____________________   (Date) __________
