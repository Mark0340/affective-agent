# Preregistration (Outline)

- Hypotheses (H1–H4): perturbation signs, recovery, convergent validity, ablations.
- Outcomes: AUC_sign, r(self-report), RMSE on segments, complexity thresholds.
- Manipulations: startle or mental arithmetic; recovery via paced breathing.
- Sensors: EDA, PPG/ECG for HR/HRV, respiration belt, optional temp.
- Analysis: mixed-effects, bootstrap CIs, permutation tests, Holm–Bonferroni.
- Data handling, risks, and consent per templates.
