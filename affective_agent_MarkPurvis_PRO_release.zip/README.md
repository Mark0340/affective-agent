# Affective Agent Prototype
Created by Mark Purvis

This is the first working prototype linking interoception, prediction error, and global workspace into a testable model of emotion & consciousness.
