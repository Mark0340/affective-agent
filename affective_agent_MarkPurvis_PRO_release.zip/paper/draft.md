# Draft Paper
This document describes the theoretical framework and implementation details.
